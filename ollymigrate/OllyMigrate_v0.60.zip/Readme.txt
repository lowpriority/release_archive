
== Files
- OllyMigrate_Od11.dll
  for OllyDbg version 1.10 (1.10 tested)
- OllyMigrate_Od20.dll
  for OllyDbg version 2.01 (2.01h tested)
- OllyMigrate_Imm17.dll
  for Immunity Debugger version 1.7x or lower (1.73 tested)
- OllyMigrate_Imm18.dll
  for Immunity Debugger version 1.8x or higher (1.85 tested)


== How to use
- Step 1 
  Install same version plugin to sender(src) and receiver(dst) debuggers.
- Step 2 
  Start sender debugger to add receiver debugger definition.
  Menu > Plugins > OllyMigrate > Options
  Input debugger info
   Path: receiver debugger path (Click [Browse] and select file)
   Tag:  anything is ok (identification only)
   Args: debugger command line argument (usually not need to change)
  Click [Add] and [Save]
- Step 3
  Open debuggee using sender debugger. Start debugging (e.g. until detect OEP)
  After that switch to another debugger. Paused status is recommended.
   Menu > Plugins > OllyMigrate > Send Debuggee
  Select destination debugger and Click [Migrate]
- Step 4
  Receiver debugger startup automatically and receive debuggee.
  Continue debugging.

  
== Known Issue
- Cannot attach process, not progress from Attaching (OllyDbg 2 Only)
  Pause on System breakpoint and Application code not supported.
  Change following OllyDbg config.
  Menu > Options > Debugging > Start
    When attaching to application, make first pause at: "No pause"
- Cannot migrate hardware and memory breakpoint
  Currently support software breakpoint(INT3) only.
  Others will be removed.


== Changelog
- v0.60 2013-04-13
  Public release version
- v0.50
  Improve: Add OllyDbg2 incompatible pause on attach config warning
  Bugfix: OllyDbg2 fail to receive break point
- v0.40
  Add: Configuration interface (Options)
  Improve: Update to OllyDbg 2 latest version PDK
  Improve: Improve migration stability
- v0.30
  Add: OllyDbg2 support
  Bugfix: Fix many bugs
- v0.20
  Add: Support Immunity Debugger
  Add: Add many features
- v0.10
  Initial version


== Bug Report
  Please try latest version before report. 
  With your environment detail, logs and way to reproduce.
   WEB:  http://low-priority.appspot.com/ollymigrate/
   MAIL: lowprio20/_at_/gmail/_dot_/com
